autorun.bat(batch file *.bat*)
ico.logo.size=191-101
AppIcon="Yes"
IconEdit=0
IconDelete=0
WindowsError "Sorry,this file can no longer be deleted because it is a required file defined for this program."
AppUninstall(1)
AppInstall(1)
div<screen.size>=800<x>600
AllowTypingCharactersandLetters(1)
WhenStarted "output "Starting Windows Devoloper Command Prompt For Windows 11 and 11 + 8.1..."
CloseApp(1)
CompatibleOperatingSystem("Win10/Win11/Win7/Win8.1/Win8.0")
VERSION "01.00"
*input_command_paramater_file <C:\Users\declan.murphy0002\Downloads\Microsoft Devoloper Command Prompt 2022.zip\Microsoft Devoloper Command Prompt 2022\Devoloper Command Prompt 2022 -Win10\command_paremeters.paremeterfile>











